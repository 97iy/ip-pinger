# bandit-ip-pinger
Simple IP Pinger

I only made this cause i like the colors now stop hating about it!
